"use strict";
exports.id = 254;
exports.ids = [254];
exports.modules = {

/***/ 7373:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Choosesimple)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5373);
/* harmony import */ var swiper_modules__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8664);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5287);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(swiper_css_navigation__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6398);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(swiper_css_pagination__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var swiper_css_scrollbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2295);
/* harmony import */ var swiper_css_scrollbar__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(swiper_css_scrollbar__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(467);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_7__);
/* __next_internal_client_entry_do_not_use__ default auto */ 

// Import Swiper React components






function Sim({ title = "Quality of water", para = " Each drop of our water is meticulously purified and safeguarded, ensuring unrivaled cleanliness and safety. Experience peace of mind with every sip." }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "xl:w-1/3 md:w-1/2 p-4 ",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "border border-gray-200 p-6 rounded-lg bg-gray-100 hover:scale-105 transition-all",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                        className: "mb-6 text-center text-xl font-bold text-[#145CAA] md:mb-6 lg:text-xl",
                        children: title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "leading-relaxed text-base",
                        children: para
                    })
                ]
            })
        })
    });
}
function Choosesimple({ ar = false }) {
    const [isMobileView, setIsMobileView] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const handleResize = ()=>{
            const { innerWidth } = window;
            setIsMobileView(innerWidth <= 640); // Adjust the threshold as per your requirements
        };
        handleResize(); // Initial check
        window.addEventListener("resize", handleResize);
        return ()=>{
            window.removeEventListener("resize", handleResize);
        };
    }, []);
    const ttitle = ar ? "    لماذا أخترتنا؟  " : "        Why Choose Us?  ";
    const tsubtitle = ar ? "         تقديم جودة وسعة وموثوقية لا هوادة فيها: مورد صهاريج المياه الموثوق به في الرياض ، مما يضمن عمليات تسليم آمنة وفي الوقت المناسب مع تقديم حلول فعالة من حيث التكلفة تتجاوز التوقعات  " : "            Delivering Uncompromising Quality, Capacity, and Reliability: Your Trusted Water Tanker Supplier in Riyadh, ensuring safe and timely deliveries while offering cost-effective solutions that exceed expectations ";
    const card = ar ? [
        {
            title: "جودة المياه",
            para: "كل قطرة ماء لدينا يتم تنقيتها وحمايتها بدقة ، مما يضمن نظافة وأمان لا مثيل لهما. اختبر راحة البال مع كل رشفة."
        },
        {
            title: "سعة",
            para: "تتمتع صهاريجنا بسعة كافية لتلبية احتياجات عملائنا ، سواء كان ذلك لموقع بناء صغير أو حدث كبير."
        },
        {
            title: "مصداقية",
            para: "نحن ، بصفتنا مورد صهاريج المياه في الرياض ، لدينا جدول تسليم موثوق به ونحن قادرون على تلبية احتياجات عملائنا في الوقت المناسب."
        },
        {
            title: "السلامة والصيانة",
            para: "نتأكد دائمًا من صيانة صهاريج المياه الخاصة بنا وتنظيفها بانتظام وفي حالة جيدة لضمان سلامة السائقين والعملاء"
        },
        {
            title: "فعاله من حيث التكلفه",
            para: "نحن لا نفرض رسومًا إضافية أبدًا ، بل نقدم أسعارًا معقولة ونقدم قيمة جيدة مقابل المال من خلال تسهيل الأمر على عملائنا."
        },
        {
            title: "  رضا العملاء",
            para: "نحن نعطي الأولوية لرضا العملاء ونسعى جاهدين لتجاوز التوقعات ، مما يضمن تجربة سلسة مع دعم العملاء الفوري والخدمة الشخصية."
        }
    ] : [
        {
            title: "Quality of water",
            para: "Each drop of our water is meticulously purified and safeguarded, ensuring unrivaled cleanliness and safety. Experience peace of mind with every sip."
        },
        {
            title: "Capacity",
            para: "Our tankers have enough capacity to meet our customers needs, whether it is for a small construction site or a large event."
        },
        {
            title: "Reliability",
            para: "We, as your water tanker supplier in Riyadh have a reliable delivery schedule and we are able to meet our customers needs in a timely manner."
        },
        {
            title: "Safety and maintenance",
            para: "We always make sure our water tankers are maintained & cleaned regularly and are in good condition to ensure the safety of the drivers and the customers"
        },
        {
            title: "Cost-effective",
            para: "We never charge extra rather we offer reasonable prices & provide good value for money by making it easy for our customers."
        },
        {
            title: " Customer Satisfaction",
            para: "We prioritize customer satisfaction and strive to exceed expectations, ensuring a seamless experience with prompt customer support and personalized service."
        }
    ];
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "text-gray-600 body-font bg-white",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container px-5 py-24 mx-auto",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-wrap  w-full mb-10 flex-col items-center text-center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            className: "mb-8 text-center text-2xl font-bold text-gray-800 md:mb-12 lg:text-3xl",
                            children: [
                                ttitle,
                                "      "
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            className: "lg:w-1/2 w-full leading-relaxed text-[#666666]",
                            children: [
                                tsubtitle,
                                "      "
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: isMobileView ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__/* .Swiper */ .tq, {
                        modules: [
                            swiper_modules__WEBPACK_IMPORTED_MODULE_3__/* .Navigation */ .W_,
                            swiper_modules__WEBPACK_IMPORTED_MODULE_3__/* .Scrollbar */ .LW,
                            swiper_modules__WEBPACK_IMPORTED_MODULE_3__/* .A11y */ .s5,
                            swiper_modules__WEBPACK_IMPORTED_MODULE_3__/* .Autoplay */ .pt
                        ],
                        // navigation
                        autoplay: {
                            delay: 2000,
                            disableOnInteraction: false
                        },
                        // speed={1000}
                        // pagination={{ clickable: true }}
                        scrollbar: {
                            draggable: true
                        },
                        spaceBetween: 50,
                        slidesPerView: 1,
                        children: card.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__/* .SwiperSlide */ .o5, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Sim, {
                                    title: item.title,
                                    para: item.para,
                                    bg: item.bg
                                })
                            }, index))
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-wrap -m-4",
                        children: card.map((item, index)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Sim, {
                                title: item.title,
                                para: item.para
                            }, index);
                        })
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 9686:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Features)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5373);
/* harmony import */ var swiper_modules__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8664);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5287);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(swiper_css_navigation__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6398);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(swiper_css_pagination__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var swiper_css_scrollbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2295);
/* harmony import */ var swiper_css_scrollbar__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(swiper_css_scrollbar__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(467);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_7__);
/* __next_internal_client_entry_do_not_use__ default auto */ 

// Import Swiper React components






function FeatureP({ title, para, bg }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex gap-4 drop-shadow-xl md:gap-6 hover:bg-gray-50 hover:scale-105 transition-all bg-cover rounded-md",
        style: {
            backgroundImage: `url(/${bg})`
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            style: {
                backgroundColor: "rgba(0, 0, 0, 0.35)"
            },
            className: "rounded p-12",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                    className: "mb-2 text-lg font-semibold md:text-xl text-white",
                    children: title
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "mb-2 text-white",
                    children: para
                })
            ]
        })
    });
}
function Features({ ar = false }) {
    const [isMobileView, setIsMobileView] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const handleResize = ()=>{
            const { innerWidth } = window;
            setIsMobileView(innerWidth <= 640); // Adjust the threshold as per your requirements
        };
        handleResize(); // Initial check
        window.addEventListener("resize", handleResize);
        return ()=>{
            window.removeEventListener("resize", handleResize);
        };
    }, []);
    const style = "grid gap-8 sm:grid-cols-2 md:gap-12 xl:grid-cols-3 xl:gap-16 md:scroll-p-8";
    const ttitle = ar ? "خدماتنا" : "Our Services";
    const tsubtitle = ar ? "نحن نقدم خدمتنا على مدار الساعة طوال أيام الأسبوع في جميع أنحاء الرياض" : "We provide our 24/7 service across Riyadh";
    const card = ar ? [
        {
            title: "سكني",
            para: "إمدادات مياه موثوقة وغير منقطعة لمنزلك ، مما يضمن مياه نقية ومنعشة في متناول يدك ، ليلاً ونهارًا",
            bg: "home.webp"
        },
        {
            title: "تجاري",
            para: "عزز أعمالك من خلال حلول المياه السلسة من Sweet Water Supply ، مما يضمن توفير إمدادات مياه عالية الجودة دون انقطاع لاحتياجاتك التجارية.",
            bg: "commercial.webp"
        },
        {
            title: "حوض سباحة",
            para: "انغمس في الكمال مع Sweet Water Supply ، مما يوفر مياه نقية للغاية لحمام السباحة الخاص بك ، مما يخلق واحة منعشة لاستمتاعك",
            bg: "swim1.webp"
        },
        {
            title: "مناسبات خاصة",
            para: "ارتقِ بمناسباتك الخاصة مع Sweet Water Supply ، مما يوفر خدمة مياه لا تشوبها شائبة تضيف لمسة من الأناقة والرقي إلى أحداثك التي لا تنسى",
            bg: "special.webp"
        },
        {
            title: "مراكز التسوق",
            para: "عزز تجربة التسوق في مركز التسوق الخاص بك باستخدام Sweet Water Supply ، مما يوفر حلاً موثوقًا وصحيًا للمياه للعملاء ، مما يحافظ على انتعاشهم طوال زيارتهم",
            bg: "mall.webp"
        },
        {
            title: "مواقع البناء",
            para: "حافظ على موقع البناء الخاص بك رطبًا وفعالًا مع Sweet Water Supply ، مما يوفر تدفقًا مستمرًا من المياه النظيفة لدعم احتياجات مشروعك ، مما يضمن عمليات سلسة في الموقع",
            bg: "construction.webp"
        }
    ] : [
        {
            title: "Residential",
            para: "Reliable and uninterrupted water supply for your home, ensuring pure and refreshing water at your fingertips, day and night",
            bg: "home.webp"
        },
        {
            title: "Commercial",
            para: "Empower your business with Sweet Water Supply's seamless water solutions, ensuring uninterrupted and quality water supply for your commercial needs.",
            bg: "commercial.webp"
        },
        {
            title: "Swimming Pools",
            para: "Dive into perfection with Sweet Water Supply, delivering crystal-clear water for your swimming pool, creating a refreshing oasis for your enjoyment",
            bg: "swim1.webp"
        },
        {
            title: "Special Occasions",
            para: "Elevate your special occasions with Sweet Water Supply, providing impeccable water service that adds a touch of elegance and sophistication to your memorable events",
            bg: "special.webp"
        },
        {
            title: "Shopping Malls",
            para: "Enhance the shopping experience at your mall with Sweet Water Supply, offering a reliable and hygienic water solution for patrons, keeping them refreshed throughout their visit.",
            bg: "mall.webp"
        },
        {
            title: "Construction Sites",
            para: "Keep your construction site hydrated and efficient with Sweet Water Supply, delivering a constant flow of clean water to support your project's needs, ensuring smooth operations on-site",
            bg: "construction.webp"
        }
    ];
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "bg-white py-6 sm:py-8 lg:py-12",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "mx-auto max-w-screen-2xl px-4 md:px-8",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mb-10 md:mb-16",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "mb-4 text-center text-2xl font-bold text-gray-800 md:mb-6 lg:text-3xl",
                            children: ttitle
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "mx-auto max-w-screen-md text-center text-gray-500 md:text-lg",
                            children: tsubtitle
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: isMobileView ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__/* .Swiper */ .tq, {
                        modules: [
                            swiper_modules__WEBPACK_IMPORTED_MODULE_3__/* .Navigation */ .W_,
                            swiper_modules__WEBPACK_IMPORTED_MODULE_3__/* .Scrollbar */ .LW,
                            swiper_modules__WEBPACK_IMPORTED_MODULE_3__/* .A11y */ .s5,
                            swiper_modules__WEBPACK_IMPORTED_MODULE_3__/* .Autoplay */ .pt
                        ],
                        // navigation
                        autoplay: {
                            delay: 2000,
                            disableOnInteraction: false
                        },
                        // speed={1000}
                        // pagination={{ clickable: true }}
                        scrollbar: {
                            draggable: true
                        },
                        spaceBetween: 50,
                        slidesPerView: 1,
                        children: card.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__/* .SwiperSlide */ .o5, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FeatureP, {
                                    title: item.title,
                                    para: item.para,
                                    bg: item.bg
                                })
                            }, index))
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: style,
                        children: card.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FeatureP, {
                                title: item.title,
                                para: item.para,
                                bg: item.bg
                            }, index))
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 2664:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\Al Khair User\Downloads\bilingualwebsite-tanker-main\app\component\choosesimple.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 2511:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ Cta)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(993);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4834);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7887);




function Cta({ ar = false }) {
    const title = ar ? "احجز صهريج المياه الآن" : "Book Your Water tanker Now";
    const sub = ar ? "اتصل بنا أو WhatsApp لنا " : "Call us or WhatsApp us.";
    const sub1 = ar ? "        سنحاول تلبية طلبك في أقرب وقت ممكن  " : "         We will try to fulfill your order as soon as possible   ";
    const b1 = ar ? "تواصل معنا    " : "Contact Us   ";
    const b2 = ar ? "  WhatsApp معنا" : "WhatsApp Us   ";
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "text-white body-font bg-cover bg-center  ",
        style: {
            backgroundImage: `url("/night.webp")`
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: " mx-auto flex px-5 py-20 md:flex-row flex-col items-center  ",
            style: {
                backgroundColor: "rgba(0, 0, 0, 0.5)"
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "lg:flex-grow md:w-1/2  flex flex-col md:items-center md:text-center items-center text-center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                        className: "title-font sm:text-4xl text-3xl mb-4 font-medium text-white",
                        children: [
                            title,
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                className: "hidden lg:inline-block"
                            }),
                            sub
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                        className: "mb-8 text-white leading-relaxed",
                        children: sub1
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: "/contact",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "hover:scale-105 inline-flex transition-all text-[#145CAA] border-[#145CAA] bg-white border-2 py-2 px-6 focus:outline-none mx-2 hover:bg-[#145CAA] rounded-md text-lg hover:text-white",
                                    children: b1
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "http://wa.me/0509201569",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "hover:scale-105 inline-flex transition-all text-green-500 border-green-500 bg-white border-2 py-2 px-6 focus:outline-none hover:bg-green-600 rounded-md text-lg hover:text-white",
                                    children: b2
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
}


/***/ }),

/***/ 8931:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\Al Khair User\Downloads\bilingualwebsite-tanker-main\app\component\feature.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 1532:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ TwoService)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(993);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);


function Serv({ title, para, img }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "sm:w-1/2 mb-10 px-4",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "rounded-lg h-64 overflow-hidden",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        alt: "content",
                        className: "object-cover  h-full w-full",
                        src: img,
                        width: 1000,
                        height: 100,
                        style: {
                            objectPosition: "center -160px  "
                        }
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                    className: "title-font text-2xl font-medium text-gray-900 mt-6 mb-3",
                    children: [
                        title,
                        "      "
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                    className: "leading-relaxed text-base",
                    children: [
                        para,
                        "        "
                    ]
                })
            ]
        })
    });
}
function TwoService({ ar = false }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: ar == false ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "text-gray-600 body-font bg-white",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container px-5 py-24 mx-auto",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-wrap -mx-4 -mb-10 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Serv, {
                            title: "Water Tanker 1",
                            img: "/long.webp",
                            para: "32000 liters of fresh Water, along with water pump for faster filling."
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Serv, {
                            title: "Water Tanker 2",
                            img: "/herob.webp",
                            para: " 18000 liters of normal potable water for swimming and other purposes with motor."
                        })
                    ]
                })
            })
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "text-gray-600 body-font bg-white",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container px-5 py-24 mx-auto",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-wrap -mx-4 -mb-10 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Serv, {
                            title: "صهريج مياه 1",
                            img: "/long.webp",
                            para: "32000 لتر من المياه العذبة مع مضخة مياه لتعبئة أسرع."
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Serv, {
                            title: "صهريج مياه 2",
                            img: "/long.webp",
                            para: "18000 لتر من مياه الشرب العادية للسباحة ولأغراض أخرى مع الموتور."
                        })
                    ]
                })
            })
        })
    });
}


/***/ })

};
;