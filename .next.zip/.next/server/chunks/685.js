"use strict";
exports.id = 685;
exports.ids = [685];
exports.modules = {

/***/ 7671:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Review)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5373);
/* harmony import */ var swiper_modules__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8664);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5287);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(swiper_css_navigation__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6398);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(swiper_css_pagination__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var swiper_css_scrollbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2295);
/* harmony import */ var swiper_css_scrollbar__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(swiper_css_scrollbar__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(467);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_8__);
/* __next_internal_client_entry_do_not_use__ default auto */ 

// Import Swiper React components







function Test({ para, name, area, img }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col items-center gap-4 sm:px-4 md:gap-6 lg:px-8 hover:scale-105 transition-all",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: " text-gray-600",
                children: para
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col items-center gap-2 sm:flex-row md:gap-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "h-12 w-12 overflow-hidden rounded-full bg-gray-100 shadow-lg md:h-14 md:w-14",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_8___default()), {
                            src: `${img}`,
                            loading: "lazy",
                            alt: " testimonial and review of users",
                            className: "h-full w-full object-cover object-center",
                            width: 50,
                            height: 50
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "text-center text-sm font-bold text-[#145CAA] sm:text-start md:text-base",
                                children: [
                                    name,
                                    "            "
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-center text-sm text-[#666666] sm:text-start md:text-sm",
                                children: area
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
function Review({ ar = false }) {
    const [isMobileView, setIsMobileView] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const handleResize = ()=>{
            const { innerWidth } = window;
            setIsMobileView(innerWidth <= 640); // Adjust the threshold as per your requirements
        };
        handleResize(); // Initial check
        window.addEventListener("resize", handleResize);
        return ()=>{
            window.removeEventListener("resize", handleResize);
        };
    }, []);
    const title = ar ? "موثوق به من قبل الأفضل" : "Trusted by the Best";
    const card = ar ? [
        {
            para: "عندما يتعلق الأمر بجودة المياه ، فإن Sweet Water Supply لا تساوم أبدًا. إن التزامهم بتوفير المياه النظيفة والآمنة ، إلى جانب الخدمة الموثوقة ، جعلهم شريكًا لا يقدر بثمن لمشاريع البناء لدينا",
            name: "عبدلله منصور",
            area: "مدير مشروع البناء",
            img: "/test1.webp"
        },
        {
            para: " بالنسبة لفعالياتنا ، فقد تجاوزت Sweet Water Supply توقعاتنا باستمرار. خدمتهم الاستثنائية ، جنبًا إلى جنب مع تفانيهم الذي لا يتزعزع لتوفير المياه النظيفة والتسليم في الموعد المحدد ، جعلتهم خيارًا لا غنى عنه.",
            name: " نفيد شيخ",
            area: "منظم الحدث",
            img: "/test3.webp"
        },
        {
            para: "لقد كان Sweet Water Supply بمثابة تغيير لقواعد اللعبة في أسرتي. إن عمليات تسليمهم الموثوقة للمياه النظيفة والآمنة ، إلى جانب أسعارها المعقولة ، جعلتهم مزودنا المفضل. أوصي بها بشدة لأي شخص يبحث عن حل مياه جدير بالثقة",
            name: "على حفصة",
            area: "مقيم | طريق ابي بكر الصديق",
            img: "/testf.webp"
        }
    ] : [
        {
            para: "When it comes to quality water, Sweet Water Supply never compromises. Their commitment to delivering clean and safe water, along with reliable service, has made them an invaluable partner for our construction projects",
            name: "Abdullah Mansoor",
            area: "Construction Project Manager",
            img: "/test1.webp"
        },
        {
            para: " For our events, Sweet Water Supply has consistently exceeded our expectations. Their exceptional service, combined with their unwavering dedication to providing clean water and punctual deliveries, has made them an indispensable choice.",
            name: " Naveed Shaikh",
            area: "Event Organizer",
            img: "/test3.webp"
        },
        {
            para: "Sweet Water Supply has been a game-changer for my household. Their reliable deliveries of clean and safe water, coupled with their affordable pricing, have made them our go-to provider. I highly recommend them to anyone seeking a trustworthy water solution",
            name: "Alia hafsa",
            area: "Resident | Abi Bakr Al-Siddiq Road",
            img: "/testf.webp"
        }
    ];
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "bg-white py-6 sm:py-8 lg:py-12 ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "mx-auto max-w-screen-xl px-4 md:px-8",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                    className: "mb-8 text-center text-2xl font-bold text-gray-800 md:mb-8 lg:text-3xl",
                    children: [
                        title,
                        "        "
                    ]
                }),
                isMobileView ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__/* .Swiper */ .tq, {
                    modules: [
                        swiper_modules__WEBPACK_IMPORTED_MODULE_3__/* .Navigation */ .W_,
                        swiper_modules__WEBPACK_IMPORTED_MODULE_3__/* .Scrollbar */ .LW,
                        swiper_modules__WEBPACK_IMPORTED_MODULE_3__/* .A11y */ .s5,
                        swiper_modules__WEBPACK_IMPORTED_MODULE_3__/* .Autoplay */ .pt
                    ],
                    navigation: true,
                    autoplay: {
                        delay: 4000,
                        disableOnInteraction: false
                    },
                    // speed={1000}
                    // pagination={{ clickable: true }}
                    //  scrollbar={{ draggable: true }}
                    spaceBetween: 50,
                    slidesPerView: 1,
                    children: card.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__/* .SwiperSlide */ .o5, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Test, {
                                name: item.name,
                                para: item.para,
                                img: item.img,
                                area: item.area
                            })
                        }, index))
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "grid gap-y-10 sm:grid-cols-2 sm:gap-y-12 lg:grid-cols-3 lg:divide-x",
                    children: card.map((item, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Test, {
                            name: item.name,
                            para: item.para,
                            img: item.img,
                            area: item.area
                        }, index);
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 5701:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(993);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7887);



function Gallery({ ar = false }) {
    const head = ar ? "معرضنا" : "Our Gallery";
    const viderr = ar ? "  متصفحك الحالي لا يدعم تشغيل الفيديو.  " : "  Your browser does not support the video tag. ";
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "text-white body-font bg-gray-800 ",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "container px-5 py-24 mx-auto flex flex-wrap",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex w-full mb-10 flex-wrap",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "sm:text-3xl text-2xl  title-font font-bold text-white lg:w-full lg:mb-0 mb-4 text-center",
                            children: head
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-wrap md:-m-2 -m-1 ",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-wrap w-1/2 ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "md:p-2 p-1 w-1/2 hover:scale-105 transition-all ",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            alt: "tanker 1",
                                            className: "w-full object-cover h-full object-center block rounded-xl",
                                            src: "/night.webp",
                                            width: 500,
                                            height: 300
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "md:p-2 p-1 w-1/2 hover:scale-105 transition-all ",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            alt: "watert tanker 2",
                                            className: "w-full object-cover h-full object-center block rounded-xl",
                                            src: "/herob.webp",
                                            width: 500,
                                            height: 300
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "md:p-2 p-1 w-full hover:scale-105 transition-all ",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            alt: "water tanker 3",
                                            className: "w-full h-full object-cover object-center block rounded-xl",
                                            src: "/hero.webp",
                                            width: 600,
                                            height: 360
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-wrap w-1/2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "md:p-2 p-1 w-full hover:scale-105 transition-all ",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            alt: "water tanker 4",
                                            className: "w-full h-full object-cover object-center block rounded-xl",
                                            src: "/long.webp",
                                            height: 600,
                                            width: 360
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "md:p-2 p-1 w-1/2 hover:scale-105 transition-all ",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("video", {
                                            width: 500,
                                            height: 300,
                                            controls: true,
                                            className: "w-full object-cover h-full object-center block rounded-xl",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                    src: "/vid1.mp4",
                                                    type: "video/mp4"
                                                }),
                                                viderr
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "md:p-2 p-1 w-1/2 hover:scale-105 transition-all ",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("video", {
                                            width: 500,
                                            height: 300,
                                            controls: true,
                                            className: "w-full object-cover h-full object-center block rounded-xl",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                    src: "/vid2.mp4",
                                                    type: "video/mp4"
                                                }),
                                                viderr
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Gallery);


/***/ }),

/***/ 5629:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ Stats)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function StatP({ number, atribute }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex flex-col items-center md:p-4 hover:scale-110",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                    className: "text-xl font-bold text-blue-500 sm:text-2xl md:text-3xl",
                    children: number
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                    className: "text-sm font-semibold text-white sm:text-base",
                    children: atribute
                })
            ]
        })
    });
}
function Stats({ ar = false }) {
    const title = ar ? "فريقنا بالأرقام  " : "Our Team by the numbers";
    const subtitle = ar ? "أداء قوي: إمداد كبير بالمياه وخدمة على مدار الساعة وقاعدة واسعة من العملاء الراضين" : "Powerful Performance: Overwhelming water supply, round the clock service, and a vast base of satisfied clients";
    const card = ar ? [
        {
            number: `۱۰۰۰۰۰ +`,
            atribute: "يتم توفير لترات من الماء"
        },
        {
            number: `۲٤/۷ `,
            atribute: "خدماتنا"
        },
        {
            number: `٥۰۰ +`,
            atribute: "عملاء سعداء"
        },
        {
            number: "  ۲ الناقلات",
            atribute: " ۱۸۰۰۰ و ۳۲۰۰۰  لتر"
        }
    ] : [
        {
            number: `100000 +`,
            atribute: "Liters of Water provided"
        },
        {
            number: `24/7 `,
            atribute: "Service"
        },
        {
            number: `500 +`,
            atribute: "Happy clients"
        },
        {
            number: " 2 Tankers",
            atribute: " 18000 and 32000 litres"
        }
    ];
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "  bg-cover bg-fixed h-4/5 bg-left",
        style: {
            backgroundImage: `url("/hero.webp")`
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "py-6 sm:py-8 lg:py-12  px-4 md:px-8 ",
            style: {
                backgroundColor: "rgba(0, 0, 0, 0.5)"
            },
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mb-10 md:mb-16 ",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "mb-4 text-center text-2xl font-bold text-white md:mb-6 lg:text-3xl",
                            children: title
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            className: "mx-auto max-w-screen-md text-center text-white md:text-lg",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "font-semibold",
                                    children: [
                                        subtitle,
                                        "    "
                                    ]
                                }),
                                " "
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "grid grid-cols-2 gap-8 md:grid-cols-4 md:gap-0  md:divide-x mx-auto max-w-screen-xl",
                    children: card.map((item, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StatP, {
                            number: item.number,
                            atribute: item.atribute
                        }, index);
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 3772:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\Al Khair User\Downloads\bilingualwebsite-tanker-main\app\component\testimonial.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;