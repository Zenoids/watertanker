"use strict";
(() => {
var exports = {};
exports.id = 155;
exports.ids = [155];
exports.modules = {

/***/ 7783:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 8530:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@opentelemetry/api");

/***/ }),

/***/ 4426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 2196:
/***/ ((module) => {

module.exports = require("next/dist/compiled/ua-parser-js");

/***/ }),

/***/ 4021:
/***/ ((module) => {

module.exports = import("next/dist/compiled/@vercel/og/index.node.js");;

/***/ }),

/***/ 8361:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  headerHooks: () => (/* binding */ headerHooks),
  originalPathname: () => (/* binding */ originalPathname),
  requestAsyncStorage: () => (/* binding */ requestAsyncStorage),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage),
  staticGenerationBailout: () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./node_modules/next/dist/build/webpack/loaders/next-metadata-route-loader.js?page=%2Ffavicon.ico%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!./app/favicon.ico?__next_metadata__
var favicon_next_metadata_namespaceObject = {};
__webpack_require__.r(favicon_next_metadata_namespaceObject);
__webpack_require__.d(favicon_next_metadata_namespaceObject, {
  GET: () => (GET),
  dynamic: () => (dynamic)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(5387);
// EXTERNAL MODULE: ./node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(9267);
var module_default = /*#__PURE__*/__webpack_require__.n(app_route_module);
// EXTERNAL MODULE: ./node_modules/next/server.js
var server = __webpack_require__(4664);
;// CONCATENATED MODULE: ./node_modules/next/dist/build/webpack/loaders/next-metadata-route-loader.js?page=%2Ffavicon.ico%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!./app/favicon.ico?__next_metadata__


const contentType = "image/x-icon"
const buffer = Buffer.from("AAABAAEAICAAAAEAIACoEAAAFgAAACgAAAAgAAAAQAAAAAEAIAAAAAAAABAAABILAAASCwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0AAAAAAEwxJAuATCQspVoXOZJTHTJdPi0Xckw4AD4vLQp2RyMnolkYOZhVHTViPSYaAAAYAwALHQAAAAAAAAAAAAAAAAAAAAAAOCwpADUqKRCGTiEtp1oXOo5RITFALiUTDBYkAhweJAAAAAAAAAAAAAAAAAAAAAAAAAAAAHBDGwBsQRoNeUceaI9SH9KiWRj2mVUc431JIo1XOCQqa0EiUYxQHcWgWBn0mlYb6oZNHaFrPhcv//I9AAAFCwAAAAAAAAAAAD0sIwAxJyQOdEUdc5RTHNehWBnzl1Ue4n5JHIdQMxoZAAgZASAbGgAAAAAAAAAAAAAAAAAAAA0DAAAgDHNEHUGeVxnupFkX4phVHJyiWBjDo1kX84VNIbqSUhvGploV6JVUG6aZVRu7pVkX/JBQGZQMEiYZAAAcCgADHQwAAx0MAAAbCVk5JVuhVxbioFcX2pFTHpucVhrQqVsW92k/IGgeFiESAAAXBQAAAABdOyQAWjklB2Y+IEeASBd9ik0ZqahbFf2ZVRqzAAAqEYVLGGarWxT/qVsV+qhbFvyVUhi7GBorKXZGJl2aVRvomVQZ2IBJG46CSBZ4gkkWeoJJFnqBSBZ3j1Edv6ZaFvl2RiCVNSYpHW1EKIWkWRbxjlAeyYNJF3+ISxZUAAAAAHBFKQBsRCoTfEolsqtcFP6sXBT/q1sU/6NYFueCShqalFIZw6tcFP+rWxT/rFwU/59XGOeFTB2mlVIZvKZaFvusXBT/rFwU/6xcFP+sXBT/rFwU/6tbFP+rWxT/q1sU/5VUHNiGTBmTlFMdz6haFfurWxT/q1sU/KpbFccAAAAAakEmAGZAJwx0RSJvm1QVr5tUFa+bVBWvnFUUsZ5VFLWdVRSzm1QVsJtUFbCbVBWwnFUUsZ1VFLWdVRS0nFQUsJtUFbCbVBWymlQVtJpUFbWXUxjBpVkV8KpbFP+qWxT/q1sU/6tbFP+rWxT/qlsU/6pbFP+qWxT8q1sUxwAAAACQaVcANichB0IvJj1ONShdTjUoXk41KF5ONSheTjUoXk41KF5ONShfTjUoX041KF9ONShfTjUoX041KF9ONShfTDQoXS4mJUMFESAhBhEfGDEnJ0GcVRbQq1sU/6pbFP+qWxT/qlsU/6pbFP+qWxT/qlsU/6lbFPuaVRqvAAAAAGA3FA6ITRxyjE8cv5BRHtKQUR7TkFEe05BRHtOQUR7TkFEe05BRHtOQUR7TkFEe05FSHdSSUh3XkVId1ZBRHtOPUR3Rj1AasXVFHFMVIDMJIx8gJ55WFcmrWxT/q1sU/6tbFP+rWxT/q1sU/6tbFP+qWxT/qVsU93NFI1tPNSgGaEAjW6FYGPCrWxT/q1sU/6tcFP+rXBT/q1wU/6tcFP+rXBT/q1wU/6tcE/+sXBT/olgX65BQGsibVRjhqVsV/6xcE/+sXBT/mVQY039JHD4YGiAnnlYVyqVaFvibVBaul1IVmZdSFZqXUhWal1IVnqlbFfKpWxT0YTYRJoRNIg+KTyC7qlsU/apbFP+rWxT/q1sU/6pbFP+rWxT/q1sU/6pbFP+qWxT/q1sU/6FXFuF9SR96RzQtNm5DIFqeVhbIq1sU/6pbFP+qWxX/i04YfBwcITWfVhXJm1ca53dFHjwAAB4LAAAeDgAAHg4zHBoSqVsW3albFPRkORMppVkYFKZaGOmqWxT/p1oV+ZJSHdCUUhrOploW949RHc+WVBrRq1sU/6pbFP+rWxT/lVIXvx0gKSooISEAAAAYB5hSFJOrWxT/qlsU/6tcFP+DSxufLiUkR59WFciYVhzijFIgMI9THwAAAAAAMygmAEMvJCinWxbjq1sV9GY6FCimWhcUploX6apbFP+kWRbxZUEpiGc/IkORUBdoVzopTnhHH5erWxT/qlsU/6tbFP+eVxfhfEkeX79xMgBpQyY2mFQZw6tbFP+qWxT/q1wU/4JLG58uJiRIn1YVyKFYGe93RyRzVTorT1g7KlJmQSpaklIasKhbFvWNTxqnYTkYFIROIhCKUCC8qVsU/aRZFvBcPCd/a0AdUppUFpZONSdWeEYcjatbFP+qWxT/qlsU/6hbFf+aVRrHc0cnb41RH6WkWRb5qlsU/6pbFP+rXBX/jE4XfBcaITKfVhXHqlsV/5tVGOiWUxrgllMZ4ZlUGualWhf5i04Zl041IyksKCkDTjUmBmpAIVqmWhf2pVkV8F49J35iOxs4jU4VZUgyJUJ5RhyPrFwU/6tbFP+rWxT/q1sT/6ZaFvqdVhrro1gX8atbE/+rWxT/rFwT/5ZTGtZ4Rx9CAAAcCopMFVWQTxRzkU8UdJJPFHWSTxR1kk8UdJFQFmNFLh4cAAwmAhEXJAAAAAUATi0UEINKG3OETSG8UzgmcFM2IUJzRiR5QC4jSGxBIH2XVB3kllQd4ZZUHeGaVRvkpVkX9KtbE/+qWxT9oFcZ7JRTHt6ITh28b0MgVkAyMAtKMykAAAAZAwAAGQUAABgFAAAYBQAAGAUAABgFAAAXAQAAHgAAAAAAAAAAAAAAGQAAABQBMR8iDGhCKyxLNCUeWjojHX1LJTVGMSQcYz4iIIlPIzuITyM6h08kNohQI3OaVhvpq1sU/6lbFf+TURquaUEkRmM/KCcxKCkKPC0pAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB+SiMAekklFI1QG0CgVhNKnlUVSoZKFykAAB0DDxMaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//////////////////////////////////////wQPwP4AD4B4AAAAMAAAADAAAAAwAAAAMAAAACAAAAAAAAAAAAAAAAAAgBwAAIAAAAAAAAAAAABgAAEB4AAD///8D////////////////////////////////////////////8=", 'base64'
  )

function GET() {
  return new server.NextResponse(buffer, {
    headers: {
      'Content-Type': contentType,
      'Cache-Control': "public, max-age=0, must-revalidate",
    },
  })
}

const dynamic = 'force-static'

;// CONCATENATED MODULE: ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Ffavicon.ico%2Froute&name=app%2Ffavicon.ico%2Froute&pagePath=private-next-app-dir%2Ffavicon.ico&appDir=C%3A%5CUsers%5CAl%20Khair%20User%5CDownloads%5Cbilingualwebsite-tanker-main%5Capp&appPaths=%2Ffavicon.ico&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!

    

    

    

    const options = {"definition":{"kind":"APP_ROUTE","page":"/favicon.ico/route","pathname":"/favicon.ico","filename":"favicon","bundlePath":"app/favicon.ico/route"},"resolvedPagePath":"next-metadata-route-loader?page=%2Ffavicon.ico%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!C:\\Users\\Al Khair User\\Downloads\\bilingualwebsite-tanker-main\\app\\favicon.ico?__next_metadata__","nextConfigOutput":""}
    const routeModule = new (module_default())({
      ...options,
      userland: favicon_next_metadata_namespaceObject,
    })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/favicon.ico/route"

    

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [381,572], () => (__webpack_exec__(8361)));
module.exports = __webpack_exports__;

})();